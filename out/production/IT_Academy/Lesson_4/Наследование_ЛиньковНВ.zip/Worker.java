package Lesson_4;

public class Worker {
    int salary;
    int age;
    String fio;

    public Worker(String fio, int salary, int age) {
        this.fio=fio;
        this.age=age;
        this.salary=salary;

    }


    public String toString () {
        String out;
        out = "ФИО: "+ this.fio+", age:"+ this.age+" " +", salary: "+ this.salary;
        return out;
    }

}
